## Hi there 👋 
   # Welcome to My GitHub Page
Hi! My name is Brandon Jones.  
This is my first GitHub Pages website.
This account is for school.
This repository is for my CTI-110 course.
My school email is bmjones14@my.waketech.edu
# About Me
## Hobbies
* Visual arts like illustration 🎨
* Fighting and Rhythm Games 🎮
## Useful Websites
* [Amazon](https://www.amazon.com/) - I primarily use Amazon for online shopping. 💰
* [Plex](https://www.plex.tv/) - I rip and store my physically owned media like music and movies onto a plex server. 📀
## Check Out My Page
Visit: [https://bmjonez14.github.io/](https://bmjonez14.github.io/)
